package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;
import sk.tuke.kpi.oop.game.weapons.Gun;

public class Erwin extends AbstractActor implements Usable<Ripley> {
    public Erwin(){
        setAnimation(new Animation("sprites/Erwin.png",20,37,0.1f,Animation.PlayMode.LOOP_PINGPONG));
    }

    @Override
    public void useWith(Ripley actor) {
        if(actor.getBackpack().getContent().stream().anyMatch(item -> item instanceof Money)){
            actor.setFirearm(new Gun(150,150));
            Money moneyToRemove = null;

            for (Collectible item : actor.getBackpack().getContent()) {
                if (item instanceof Money) {
                    moneyToRemove = (Money) item;
                    break;
                }
            }
            if (moneyToRemove != null) {
                actor.getBackpack().remove(moneyToRemove);
            }
        }
        else{
            actor.getHealth().drain(50);
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
