package sk.tuke.kpi.oop.game.controllers;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Input;
import sk.tuke.kpi.gamelib.KeyboardListener;
import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.actions.Drop;
import sk.tuke.kpi.oop.game.actions.Shift;
import sk.tuke.kpi.oop.game.actions.Take;
import sk.tuke.kpi.oop.game.actions.Use;
import sk.tuke.kpi.oop.game.items.Usable;

public class KeeperController implements KeyboardListener {
    private Keeper keeper;

    public KeeperController(Keeper keeper) {
        this.keeper = keeper;
    }

    @Override
    public void keyPressed(@NotNull Input.Key key) {
        if (key == Input.Key.O) {
            new Take<>().scheduleFor(keeper);
        } else if (key == Input.Key.P) {
            new Drop<>().scheduleFor(keeper);
        } else if (key == Input.Key.C) {
            new Shift<>().scheduleFor(keeper);
        } else if (key == Input.Key.U) {
            useAction();
        } else if (key == Input.Key.B) {
            bAction();
        }
    }

    private void bAction() {
        if (keeper.getBackpack().peek() instanceof Usable) {
            Usable<?> usable = (Usable<?>) keeper.getBackpack().peek();
            new Use<>(usable).scheduleForIntersectingWith(keeper);
        }
    }

    private void useAction() {
        Usable<?> usable = keeper.getScene().getActors().stream()
            .filter(Usable.class::isInstance)
            .filter(keeper::intersects)
            .map(Usable.class::cast)
            .findFirst()
            .orElse(null);
        if (usable != null) {
            new Use<>(usable).scheduleForIntersectingWith(keeper);
        }
    }
}
