package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.characters.Ripley;

public interface InteractionStrategy {
    void interact(Ripley ripley);
}
