package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class Light extends AbstractActor implements Switchable, EnergyConsumer{
    private Animation lightOffAnimation;
    private Animation lightOnAnimation;
    private boolean isOn;
    private boolean isPowered;

    public Light() {
        isPowered = false;
        isOn = false;
        lightOffAnimation = new Animation("sprites/light_off.png", 16, 16);
        lightOnAnimation = new Animation("sprites/light_on.png", 16, 16);
        setAnimation(lightOffAnimation);
    }

    public void toggle() {
        if (isOn == false) {
            isOn = true;
            updateAnimation();
        } else {
            isOn = false;
            updateAnimation();
        }
    }
    public void setPowered(boolean powered) {
        this.isPowered = powered;
        updateAnimation();
    }

    public void updateAnimation() {
        if (isOn == true && isPowered == true) {
            setAnimation(lightOnAnimation);
        } else {
            setAnimation(lightOffAnimation);
        }

    }

    @Override
    public void turnOn() {
        isOn = true;
        updateAnimation();
    }

    @Override
    public void turnOff() {
        isOn = false;
        updateAnimation();
    }

    @Override
    public boolean isOn() {
        return isOn;
    }

}
