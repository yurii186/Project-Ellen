package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.ActorContainer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Backpack implements ActorContainer<Collectible> {
    private final String name;
    private final int anInt;
    private List<Collectible> list = new ArrayList<>();


    public Backpack(String name, int capacity) {
        this.name = name;
        this.anInt = capacity;
    }

    @Override
    public @NotNull List<Collectible> getContent() {
        return List.copyOf(list);
    }

    @Override
    public int getCapacity() {
        return anInt;
    }

    @Override
    public int getSize() {
        return list.size();
    }

    @Override
    public @NotNull String getName() {
        return name;
    }

    @Override
    public void add(@NotNull Collectible actor) {
        if (list.size() < getCapacity()) {
            list.add(actor);
        }
        else  {
            throw new IllegalStateException(getName()+" is full");
        }
    }

    @Override
    public void remove(@NotNull Collectible actor) {
        if (list !=null)
            list.remove(actor);
    }

    @NotNull
    @Override
    public Iterator<Collectible> iterator() {
        return list.iterator();
    }

    @Nullable
    @Override
    public Collectible peek() {
        if (getSize()>0) {
            return list.get(getSize()-1);
        }
        else {
            return null;
        }
    }

    @Override
    public void shift() {
        Collections.rotate(list, 1);
    }

}

