package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;


public class Heart extends AbstractActor implements Usable<Ripley>, Collectible {

    public Heart(){
        setAnimation(new Animation("sprites/heart.png", 16, 16));
    }

    private void damage() {
        Scene scene = getScene();
        if (scene == null) return;

        for (var actor : scene.getActors()) {
            if (this.intersects(actor) && actor instanceof Alive) {
                    ((Alive) actor).getHealth().drain(1);
            }
        }
    }

    @Override
    public void useWith(Ripley actor) {
        if(actor instanceof  Alive){
            ((Alive) actor).getHealth().drain(100);
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
         new Loop<>(new ActionSequence<>(new Invoke<>(this::damage), new Wait<>(1))).scheduleOn(scene);
       // new Loop<>(new Invoke<>(this::damage)).scheduleOn(scene);
    }
}
