package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class LaserInteraction implements InteractionStrategy {
    @Override
    public void interact(Ripley ripley) {
        if (!ripley.isInvincible()) {
            ((Alive) ripley).getHealth().drain(10);
        }
    }
}
