package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.items.Backpack;
import sk.tuke.kpi.oop.game.items.Collectible;

public class GiveHeartCommand implements Command {
    private Heart heart;
    private Backpack backpack;

    public GiveHeartCommand(Heart heart, Backpack backpack) {
        this.heart = heart;
        this.backpack = backpack;
    }

    @Override
    public void execute() {
        backpack.add((Collectible) heart);
    }
}
