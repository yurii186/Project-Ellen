package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Backpack;
import sk.tuke.kpi.oop.game.items.Usable;
import sk.tuke.kpi.oop.game.openables.Openable;

import java.util.Timer;
import java.util.TimerTask;


public class Tunnel extends AbstractActor implements Usable<Ripley>, Openable {
    private boolean isOpen;

    public Tunnel() {
        setAnimation(new Animation("sprites/tunnel.png", 32, 32, 0.1f, Animation.PlayMode.ONCE));
        getAnimation().stop();
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor.getBackpack().getContent().stream().anyMatch(item -> item instanceof Body) && actor.getBackpack().getContent().stream().anyMatch(item -> item instanceof Heart)) {
            CenteredImageActor winImage = new CenteredImageActor("sprites/win.png", 750, 375);
            if (getScene() != null) {
                Scene scene = getScene();
                scene.addActor(winImage, scene.getGame().getWindowSetup().getWidth(), scene.getGame().getWindowSetup().getHeight());
                scene.follow(winImage);
                end();
            }
        } else if (actor.getBackpack().getContent().stream().anyMatch(item -> item instanceof Body)) {
            actor.getHealth().drain(100);
        }
    }


    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }

    @Override
    public void open() {
        if (!isOpen) {
            isOpen = true;
            setAnimation(new Animation("sprites/tunnel.png", 32, 32, 0.1f, Animation.PlayMode.ONCE));
            getAnimation().play();
        }
    }

    @Override
    public void close() {
        if (isOpen) {
            isOpen = false;
            setAnimation(new Animation("sprites/tunnel.png", 32, 32, 0.1f, Animation.PlayMode.ONCE_REVERSED));
            getAnimation().play();
        }
    }

    @Override
    public boolean isOpen() {
        return isOpen;
    }
    public void updateInventory() {
        Ripley ripley = getScene().getFirstActorByType(Ripley.class);
        if (hasBody(ripley.getBackpack())) {
            open();
        }
        else {
            close();
        }
    }

    private boolean hasBody(Backpack backpack) {
        return backpack.getContent().stream().anyMatch(item -> item instanceof Body);
    }
    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
        new Loop<>(new Invoke<>(this::updateInventory)).scheduleOn(scene);
    }
    public void end(){
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {@Override public void run() {getScene().getGame().stop();}}, 10000);
    }
}
