package sk.tuke.kpi.oop.game.characters;

import java.util.ArrayList;
import java.util.List;

public class Health {
    private int hp;
    private int maxhp;
    private List<FatigueEffect> effects;

    public Health(int initialhp, int maxhp) {
        this.hp = initialhp;
        this.maxhp = maxhp;
        effects = new ArrayList<>();
    }

    public Health(int initialhp) {
        this.hp = initialhp;
        this.maxhp = this.hp;
    }

    public int getValue() {
        return this.hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void setMaxhp(int maxhp) {
        this.maxhp = maxhp;
    }

    public void refill(int amount) {
        if (hp + amount <= maxhp) {
            hp += amount;
        } else {
            restore();
        }
    }

    public void restore() {
        hp = maxhp;
    }

    public void drain(int amount) {
        if (hp != 0) {
            if (hp > amount) {
                hp -= amount;
            } else {
                exhaust();
            }
        }
    }

    public void exhaust() {
        if (hp != 0) {
            hp = 0;
            if (effects != null) {
                effects.forEach(FatigueEffect::apply);
            }
        }
    }

    @FunctionalInterface
    public interface FatigueEffect {
        void apply();
    }

    public void onFatigued(FatigueEffect effect) {
        if (effects != null) {
            effects.add(effect);
        }
    }
}
