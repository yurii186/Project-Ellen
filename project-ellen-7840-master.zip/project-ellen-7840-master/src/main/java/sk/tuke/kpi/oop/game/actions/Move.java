package sk.tuke.kpi.oop.game.actions;

import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Action;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.Direction;

public class Move<A extends Movable> implements Action<A> {
    private Direction direction;
    private float duration;
    private boolean done;
    private A actor;
    private int time;

    public Move(Direction direction, float duration) {
        this.direction = direction;
        this.duration = duration;
        done = false;
    }

    public Move(Direction direction) {
        this.direction = direction;
        done = false;
    }
    @Nullable
    @Override
    public A getActor() {
        return actor;
    }

    public void setActor(@Nullable A movable) {
        this.actor = movable;
    }

    @Override
    public boolean isDone() {
        return done;
    }

    @Override
    public void reset() {
        actor.stoppedMoving();
        done = false;
        duration = 0;
    }
    @Override
    public void execute(float deltaTime) {
        if (getActor() == null) {
            return;
        }

        duration -= deltaTime;

        if (!isDone()) {
            if (time == 0) {
                actor.startedMoving(direction);
                time++;
            }

            if (duration > 0) {
                int newPosX = actor.getPosX() + direction.getDx() * actor.getSpeed();
                int newPosY = actor.getPosY() + direction.getDy() * actor.getSpeed();

                actor.setPosition(newPosX, newPosY);

                Scene actorScene = getActor().getScene();
                if (actorScene != null && actorScene.getMap().intersectsWithWall(actor)) {
                    actor.setPosition(actor.getPosX() - direction.getDx() * actor.getSpeed(), actor.getPosY() - direction.getDy() * actor.getSpeed());
                     actor.collidedWithWall();
                }
            } else {
                stop();
            }
        }
    }


    public void stop() {
        if (actor != null) {
            done = true;
            actor.stoppedMoving();
        }
    }
}
