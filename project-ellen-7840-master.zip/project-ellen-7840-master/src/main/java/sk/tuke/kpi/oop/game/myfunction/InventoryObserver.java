package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.items.Backpack;

public interface InventoryObserver {
    void updateInventory(Backpack backpack);
}
