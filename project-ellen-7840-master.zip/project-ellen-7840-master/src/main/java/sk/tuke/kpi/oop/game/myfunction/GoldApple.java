package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;

import java.util.Timer;
import java.util.TimerTask;

public class GoldApple extends AbstractActor implements Collectible, Usable<Actor> {
    private boolean isEaten;

    public GoldApple(){
        setAnimation(new Animation("sprites/golden_apple.png",16,16));
    }

    @Override
    public void useWith(Actor actor) {
        eat();
        getScene().removeActor(this);
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }

    public void eat() {
        isEaten = true;
        CenteredImageActor winImage = new CenteredImageActor("sprites/win.png", 750, 375);
        if (getScene() != null) {
            Scene scene = getScene();
            scene.addActor(winImage, scene.getGame().getWindowSetup().getWidth(), scene.getGame().getWindowSetup().getHeight());
            scene.follow(winImage);
            end();
        }
    }

    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
        if (isEaten && scene != null) {
            eat();
        }
    }
    public void end(){
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {@Override public void run() {getScene().getGame().stop();}}, 10000);
    }
}
