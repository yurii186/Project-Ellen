package sk.tuke.kpi.oop.game;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.actions.PerpetualReactorHeating;
import sk.tuke.kpi.oop.game.items.Hammer;
import java.util.HashSet;
import java.util.Set;

public class Reactor extends AbstractActor implements Switchable, Repairable {
    private int temperature;
    private int damage;
    private Animation normalAnimation;
    private Animation reactorOffAnimation;
    private Animation hotAnimation;
    private Animation brokenAnimation;

    private Animation extinguishedAnimation;
    private Light light;
    private Set<EnergyConsumer> devices;
    private boolean isOn;

    public Reactor() {
        isOn = false;
        devices = new HashSet<>();
        this.temperature = 0;
        this.damage = 0;
        normalAnimation = new Animation("sprites/reactor_on.png", 80, 80, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        hotAnimation = new Animation("sprites/reactor_hot.png", 80, 80, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        brokenAnimation = new Animation("sprites/reactor_broken.png", 80, 80);
        reactorOffAnimation = new Animation("sprites/reactor.png", 80, 80);
        extinguishedAnimation = new Animation("sprites/reactor_extinguished.png", 80, 80);
        //setAnimation(normalAnimation);
        updateAnimation();
    }

    public int getTemperature() {
        return temperature;
    }

    public int getDamage() {
        return damage;
    }

    public void increaseTemperature(int increment) {
        if (isOn && increment >= 0) {
            if (damage >= 33 && damage <= 66) {
                temperature = (int) (temperature + (1.5 * increment));
            } else if (damage > 66) {
                temperature = temperature + (2 * increment);
            } else {
                temperature = temperature + increment;
            }

            if (temperature > 2000) {
                int temp = temperature - 2000;
                this.damage = (int) Math.floor((100 * temp) / 4000);
            }

            if (damage >= 100) {
                damage = 100;
                isOn = false;
            }
            updateAnimation();
        }
    }

    public void decreaseTemperature(int decrement) {
        if (isOn == true && decrement > 0) {
            if (damage >= 50 && damage < 100 && temperature > 0) {
                int newDecrement = (int) Math.floor(decrement / 2);
                temperature = temperature - newDecrement;
                updateAnimation();
            } else if (damage == 100) {
                updateAnimation();
            } else {
                temperature = temperature - decrement;
                updateAnimation();
            }
            if (temperature < 0) {
                temperature = 0;
            }
        }
    }

    private void updateAnimation() {
        if (isOn == true) {
            if (temperature > 4000 && temperature < 6000) {
                setAnimation(hotAnimation);
            } else if (temperature == 6000) {
                setAnimation(brokenAnimation);
                isOn = false;
            } else {
                setAnimation(normalAnimation);
            }
        } else {
            setAnimation(reactorOffAnimation);
        }
        if(damage == 100)
            setAnimation(brokenAnimation);
        updateAllDevices();
    }


    public boolean repair() {
        if (damage > 0 && damage < 100) {
            temperature = (int) (((damage - 50) / 0.025) + 2000);
            if (damage > 50) {
                damage = damage - 50;
                updateAnimation();
            } else {
                damage = 0;
                updateAnimation();
            }
            return true;
        }
        return false;
    }

    public void turnOn() {
        if (this.getDamage() >= 100) {
            isOn = false;
        } else {
            isOn = true;
            updateAnimation();
        }

    }

    public void turnOff() {
        if (temperature >= 6000) {
            setAnimation(brokenAnimation);
        } else {
            setAnimation(reactorOffAnimation);
        }
        isOn = false;
        updateAllDevices();
    }

    public boolean isOn() {
        if (isOn) {
            return true;
        } else {
            return false;
        }
    }

    /* public boolean isRunning() {
        return this.isRunning;
    } */

    /*public void addLight(Light light) {
        this.light = light;
        light.setElectricityFlow(true);
        light.turnOn();
        updateLight();
    } */
    public void addDevice(EnergyConsumer device) {
        this.devices.add(device);
        if (damage == 0 && isOn()) {
            device.setPowered(true);
        }
        device.setPowered(isOn());
    }


    /* public void removeLight(Light light) {
         this.light = light;
         light.setElectricityFlow(false);
         light.turnOff();
         updateLight();
     }*/
    public void removeDevice(EnergyConsumer device) {
        device.setPowered(false);
        this.devices.remove(device);
    }


    public void updateLight() {
        if (isOn == true && damage != 100) {
            this.light.setPowered(true);
        } else if (isOn == false) {
            this.light.setPowered(false);
        } else {
            this.light.setPowered(false);
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        // scene.scheduleAction(new PerpetualReactorHeating(1),this);
        new PerpetualReactorHeating(1).scheduleFor(this);
    }

    public boolean extinguish() {
        if (damage != 100 || isOn == true)
            return false;
        else {
            temperature = 4000;
            setAnimation(extinguishedAnimation);
            return true;
        }
    }

    private boolean isElectricity() {
        if (isOn() && damage != 100) {
            return true;
        } else {
            return false;
        }
    }

    private void updateStateOfDevice(EnergyConsumer device) {
        device.setPowered(isElectricity());
    }

    private void updateAllDevices() {
        this.devices.forEach(this::updateStateOfDevice);
    }

    public void useWith(Hammer hammer) {
        hammer.useWith(this);
    }
}
