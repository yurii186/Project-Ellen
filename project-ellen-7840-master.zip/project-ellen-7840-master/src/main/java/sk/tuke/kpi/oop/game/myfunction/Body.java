package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;

public class Body extends AbstractActor implements Usable<Ripley>, Collectible {

    private boolean use;
    public Body() {
        setAnimation(new Animation("sprites/body.png", 64, 48));
        use = true;
    }

    @Override
    public void useWith(Ripley actor) {
        Apple apple = new Apple();
        if (apple instanceof Collectible && use == true) {
            actor.getBackpack().add((Collectible) apple);
            use = false;
        }
    }


    @Override
    public Class<Ripley> getUsingActorClass() {return Ripley.class;}

}
