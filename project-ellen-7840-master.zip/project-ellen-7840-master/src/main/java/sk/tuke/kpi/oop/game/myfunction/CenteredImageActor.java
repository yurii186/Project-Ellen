package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;


public class CenteredImageActor extends AbstractActor {

    public CenteredImageActor(String imagePath, int width, int height) {
        setAnimation(new Animation(imagePath, width, height));
    }

    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);

        if (scene != null) {
            setPosition(scene.getGame().getWindowSetup().getWidth(), scene.getGame().getWindowSetup().getHeight());
        }
    }
}
