package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.oop.game.characters.Alien;
import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.oop.game.characters.Ripley;

import java.util.Timer;
import java.util.TimerTask;

public class SpawnPoint extends AbstractActor {
    private int enemiesToSpawn;
    private boolean activated;
    private boolean spawnAllowed;

    public SpawnPoint(int enemiesToSpawn) {
        this.enemiesToSpawn = enemiesToSpawn;
        this.activated = true;
        this.spawnAllowed = true;
        setAnimation(new Animation("sprites/spawn.png", 32, 32));
    }

    public void activate() {
        this.activated = true;
    }

    public void deactivate() {
        this.activated = false;
    }

    public boolean isActivated() {
        return activated;
    }

    public int getEnemiesToSpawn() {
        return enemiesToSpawn;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        new Loop<>(new Invoke<>(this::spawnAliensIfNeeded)).scheduleFor(this);
    }

    private double distanceTo(Ripley ripley) {
        int x1 = this.getPosX();
        int y1 = this.getPosY();
        int x2 = ripley.getPosX();
        int y2 = ripley.getPosY();

        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
    private void spawnAliensIfNeeded() {
        if (!activated || !spawnAllowed) return;

        Ripley ripley = getScene().getFirstActorByType(Ripley.class);
        if (ripley != null && distanceTo(ripley) <= 50) {
            int aliensOnMap = 0;
            for (Actor actor : getScene().getActors()) {
                if (actor instanceof Alien) {
                    aliensOnMap++;
                //    System.out.println(aliensOnMap);
                }
            }

            if (aliensOnMap == 1) {
                deactivate();
                scheduleSpawnCooldown();
                spawnAliens();
                System.out.println("Prvuy");
            } else if (aliensOnMap == 0) {
                spawnAliens();
                activate();
                System.out.println("Druhy");
            }
        }
    }




    private void scheduleSpawnCooldown() {
        spawnAllowed = false;
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                spawnAllowed = true;
            }
        };
        timer.schedule(task, 3000);
    }

    private void spawnAliens() {
            Alien alien = new Alien();
            alien.setPosition(this.getPosX(), this.getPosY());
            getScene().addActor(alien);
    }
}

