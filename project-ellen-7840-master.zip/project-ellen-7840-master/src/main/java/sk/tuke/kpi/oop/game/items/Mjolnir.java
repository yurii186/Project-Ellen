package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.Scene;

public class Mjolnir extends Hammer {

    private int remainingUses;

    public Mjolnir() {
        super();
        this.remainingUses = 4;
    }
    public int getRemainingUses(){return remainingUses;}
    public void use() {
        if (remainingUses > 0) {
            remainingUses--;
            if (remainingUses < 1) {
                Scene scene = getScene();
                scene.removeActor(this);
            }
        }
    }
}
