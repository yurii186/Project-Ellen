package sk.tuke.kpi.oop.game;

public interface Switchable {
    void turnOn();
    void turnOff();
    boolean isOn();
}
