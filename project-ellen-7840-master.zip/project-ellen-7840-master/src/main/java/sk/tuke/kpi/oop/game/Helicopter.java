package sk.tuke.kpi.oop.game;


import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.Player;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class Helicopter extends AbstractActor {
    private int X = 0, Y = 0;

    public Helicopter() {
        setAnimation(new Animation("sprites/heli.png", 64, 64, 0.2f, Animation.PlayMode.LOOP_PINGPONG));

    }

    public void searchAndDestroy() {
        new Loop<>(new Invoke<>(this::searchActor)).scheduleFor(this);
    }



    private void searchActor() {
        Player helicopter = getScene().getLastActorByType(Player.class);

        if (this.getPosY() != helicopter.getPosY()) {
            if(this.getPosY() > helicopter.getPosY()) {
                Y = this.getPosY()- 1;
            } else {
                Y = this.getPosY() + 1;
            }
        }

        if (this.getPosX() != helicopter.getPosX()) {
            if(this.getPosX() > helicopter.getPosX()) {
                X = this.getPosX()- 1;
            } else {
                X = this.getPosX() + 1;
            }
        }

        this.setPosition(X, Y);

        if (intersects(helicopter)) {
            helicopter.setEnergy(helicopter.getEnergy()-1);
        }
    }
}

