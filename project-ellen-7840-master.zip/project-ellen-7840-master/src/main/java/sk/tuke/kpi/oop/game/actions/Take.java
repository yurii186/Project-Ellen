
package sk.tuke.kpi.oop.game.actions;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.items.Collectible;

import java.util.List;
import java.util.Objects;

public class Take<K extends Keeper> extends AbstractAction<K> {

    public Take() {}

    @Override
    public void execute(float deltaTime) {
        if (shouldAbortExecution()) {
            setDone(true);
            return;
        }

        Scene scene = getActor().getScene();
        List<Actor> itemsInScene = Objects.requireNonNull(scene).getActors();

        for (Actor item : itemsInScene) {
            if (item instanceof Collectible && item.intersects(getActor())) {
                try {
                    addToBackpackAndRemoveItem((Collectible) item, scene);
                    break;
                } catch (IllegalStateException exception) {
                    handleIllegalStateException(scene, exception);
                }
            }
        }

        setDone(true);
    }

    private boolean shouldAbortExecution() {
        return getActor() == null || getActor().getScene() == null || isDone();
    }

    private void addToBackpackAndRemoveItem(Collectible item, Scene scene) {
        getActor().getBackpack().add(item);
        scene.removeActor(item);
    }

    private void handleIllegalStateException(Scene scene, IllegalStateException exception) {
        scene.getOverlay().drawText(exception.getMessage(), 0, 0).showFor(2);
    }
}
