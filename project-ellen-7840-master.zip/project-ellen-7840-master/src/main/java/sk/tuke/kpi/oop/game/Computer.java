package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class Computer extends AbstractActor implements EnergyConsumer{

    private boolean powered;

    public Computer() {
        Animation normalAnimation = new Animation("sprites/computer.png", 80, 48, 0.2f);
        setAnimation(normalAnimation);
    }

    public int add(int num1, int num2) {
        if (!powered)
            return 0;
        return num1 + num2;
    }

    public int sub(int num1, int num2) {
        if (!powered)
            return 0;
        return num1 - num2;
    }

    public float add(float num1, float num2) {
        if (!powered)
            return 0;
        return num1 + num2;
    }

    public float sub(float num1, float num2) {
        if (!powered)
            return 0;
        return num1 - num2;
    }

    private void updateAnimation() {
        if (powered) {
            this.getAnimation().play();
        }
        this.getAnimation().pause();
    }


    public void setPowered(boolean powered) {

        this.powered = powered;
        this.updateAnimation();
    }
}
