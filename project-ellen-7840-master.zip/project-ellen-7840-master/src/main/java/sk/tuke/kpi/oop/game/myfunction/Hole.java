package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Alien;
import sk.tuke.kpi.oop.game.items.Usable;

import java.util.Timer;
import java.util.TimerTask;

public class Hole extends AbstractActor implements Usable<Actor> {
    private boolean isOpen;

    public Hole() {
        setAnimation(new Animation("sprites/hole.png", 32, 32, 0.1f, Animation.PlayMode.ONCE));
        getAnimation().stop();
        isOpen = false;
    }

    private void updateState() {
        isOpen = getScene().getActors().stream().anyMatch(actor -> actor instanceof Alien);

        if (!isOpen) {
            getAnimation().play();
        } else {
            getAnimation().stop();
        }
    }

    @Override
    public void useWith(Actor actor) {
        CenteredImageActor winImage = new CenteredImageActor("sprites/win.png", 750, 375);
        if (getScene() != null) {
            Scene scene = getScene();
            scene.addActor(winImage, scene.getGame().getWindowSetup().getWidth(), scene.getGame().getWindowSetup().getHeight());
            scene.follow(winImage);
            end();
        }
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }

    @Override
    public void addedToScene(Scene scene) {
            super.addedToScene(scene);
            new Loop<>(new Invoke<>(this::updateState)).scheduleOn(scene);
    }
    public void end(){
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {@Override public void run() {getScene().getGame().stop();}}, 10000);
    }
}
