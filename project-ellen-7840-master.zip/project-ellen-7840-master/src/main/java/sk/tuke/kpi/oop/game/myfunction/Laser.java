package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class Laser extends AbstractActor {


    private InteractionStrategy interactionStrategy = new LaserInteraction();

    public Laser() {
        setAnimation(new Animation("sprites/laser_beam.png", 16, 16));
    }

    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
        new Loop<>(new Invoke<>(this::checkForPlayer)).scheduleOn(scene);
    }

    private void checkForPlayer() {
        Scene scene = getScene();
        if (scene == null) return;

        for (var actor : scene.getActors()) {
            if (actor instanceof Ripley && this.intersects(actor)) {
                Ripley ripley = (Ripley) actor;
                interactionStrategy.interact(ripley);
                return;
            }
        }
    }
}
