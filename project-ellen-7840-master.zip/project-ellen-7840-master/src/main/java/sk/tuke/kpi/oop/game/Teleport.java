package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
//import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
//import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.Player;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;

import java.util.List;

public class Teleport extends AbstractActor {
    private Teleport destinationTeleport;
    private boolean playerInsideTeleport = false;
    private boolean NULL = false;

    public Teleport() {
        setAnimation(new Animation("sprites/lift.png"));
    }
    public Teleport getDestination() {
        if(NULL)
            return null;
        return destinationTeleport;
    }

    public Teleport(Teleport destinationTeleport) {
        this();
        //this.destinationTeleport = destinationTeleport;
        setDestination(destinationTeleport);
    }

    public void setDestination(Teleport destinationTeleport) {
        if (destinationTeleport == null) {
            this.destinationTeleport = new Teleport();
            this.NULL = true;
        }
        else if (destinationTeleport != this) {
            this.destinationTeleport = destinationTeleport;
            this.NULL = false;
        }
    }

    public void teleportPlayer(Player player) {
        if (destinationTeleport != null) {
            int targetX = this.getPosX() + (this.getWidth() / 2) - (player.getWidth() / 2);
            int targetY = this.getPosY() + (this.getHeight() / 2) - (player.getHeight() / 2);
            player.setPosition(targetX, targetY);
            playerInsideTeleport = true;
            destinationTeleport.playerInsideTeleport = false;
        }
    }


    private void checkForPlayer() {
       // System.out.println("Checking for players...");

        List<Actor> actors = getScene().getActors();

        for (Actor actor : actors) {
            if (actor instanceof Player) {
                Player player = (Player) actor;
                int playerX = player.getPosX() + (player.getWidth() / 2);
                int playerY = player.getPosY() + (player.getHeight() / 2);
                if (contains(playerX, playerY)) {
                    if (!playerInsideTeleport && destinationTeleport != null) {
                        //System.out.println("Checking for players...");
                            destinationTeleport.teleportPlayer(player);
                        destinationTeleport.playerInsideTeleport = true;
                    }
                } else {
                    playerInsideTeleport = false;
                }
            }
        }
    }

    private boolean contains(int x, int y) {
        int minX = getPosX();
        int minY = getPosY();
        int maxX = getPosX() + getWidth();
        int maxY = getPosY() + getHeight();
        return (x >= minX && x <= maxX && y >= minY && y <= maxY);
    }


    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
        // new Loop<>(new ActionSequence<>(new Invoke<>(this::checkForPlayer), new Wait<>(1))).scheduleOn(scene);
        new Loop<>(new Invoke<>(this::checkForPlayer)).scheduleOn(scene);
    }
}
