package sk.tuke.kpi.oop.game.scenarios;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.*;
import sk.tuke.kpi.oop.game.behaviours.RandomlyMoving;
import sk.tuke.kpi.oop.game.characters.Alien;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.controllers.KeeperController;
import sk.tuke.kpi.oop.game.controllers.MovableController;
import sk.tuke.kpi.oop.game.controllers.ShooterController;
import sk.tuke.kpi.oop.game.myfunction.*;
import sk.tuke.kpi.oop.game.openables.LockedDoor;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class Game implements SceneListener {

    public static class Factory implements ActorFactory {
        @Override
//        public @Nullable Actor create(@Nullable String type, @Nullable String name) {
//            assert name != null;
//            switch (name) {
//                case "player":
//                    return new Ripley();
//                case "door":
//                    return new LockedDoor();
//                case "wallswitch":
//                    return new WallSwitch();
//                case "body":
//                    return new Body();
//                case "laser1":
//                    return new Laser();
//                case "laser2":
//                    return new Laser();
//                case "laser3":
//                    return new Laser();
//                case "laser4":
//                    return new Laser();
//                case "laser5":
//                    return new Laser();
//                case "laser6":
//                    return new Laser();
//                case "laser7":
//                    return new Laser();
//                case "laser8":
//                    return new Laser();
//                case "laser9":
//                    return new Laser();
//                case "buttongreen":
//                    return new ButtonGreen();
//                case "alien":
//                    return new Alien(1, new RandomlyMoving());
//                case "hole":
//                    return new Hole();
//                case "tunnel":
//                    return new Tunnel();
//                default:
//                    return null;
//            }
//        }
//    }
        public @Nullable Actor create(@Nullable String type, @Nullable String name) {
            assert name != null;

            Map<String, Supplier<Actor>> actors = new HashMap<>();
            actors.put("player", Ripley::new);
            actors.put("door", LockedDoor::new);
            actors.put("wallswitch", WallSwitch::new);
            actors.put("body", Body::new);
            actors.put("laser1", Laser::new);
            actors.put("laser2", Laser::new);
            actors.put("laser3", Laser::new);
            actors.put("laser4", Laser::new);
            actors.put("laser5", Laser::new);
            actors.put("laser6", Laser::new);
            actors.put("laser7", Laser::new);
            actors.put("laser8", Laser::new);
            actors.put("laser9", Laser::new);
            actors.put("buttongreen", ButtonGreen::new);
            actors.put("alien", () -> new Alien(3200, new RandomlyMoving()));
            actors.put("hole", Hole::new);
            actors.put("tunnel", Tunnel::new);
            actors.put("money", Money::new);
            actors.put("Erwin", Erwin::new);

            return actors.getOrDefault(name, () -> null).get();
        }
    }
    @Override
    public void sceneInitialized(@NotNull Scene scene) {
        Ripley player = scene.getFirstActorByType(Ripley.class);
        scene.follow(player);
        scene.getGame().pushActorContainer(player.getBackpack());

        Disposable movableCon = scene.getInput().registerListener(new MovableController(player));
        Disposable keeperCon = scene.getInput().registerListener(new KeeperController(player));
        Disposable shooterCon = scene.getInput().registerListener(new ShooterController(player));



        scene.getMessageBus().subscribe(Ripley.RIPLEY_DIED, (Ripley) -> movableCon.dispose());
        scene.getMessageBus().subscribe(Ripley.RIPLEY_DIED, (Ripley) -> keeperCon.dispose());
        scene.getMessageBus().subscribe(Ripley.RIPLEY_DIED, (Ripley) -> shooterCon.dispose());

        sceneUpdating(scene);
    }
    @Override
    public void sceneUpdating(@NotNull Scene scene) {
        Ripley player = scene.getFirstActorByType(Ripley.class);
        assert player != null;
        player.showRipleyState();
    }

}
