package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.items.Backpack;

public class GiveAppleCommand implements Command {
    private Apple apple;
    private Backpack backpack;

    public GiveAppleCommand(Apple apple, Backpack backpack) {
        this.apple = apple;
        this.backpack = backpack;
    }

    @Override
    public void execute() {
        backpack.add(apple);
    }
}
