package sk.tuke.kpi.oop.game.characters;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Disposable;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.behaviours.Behaviour;

import java.util.List;

public class Alien extends AbstractActor implements Movable, Alive, Enemy {
    private Health health;
    private Behaviour<? super Alien> behaviour;
    private Disposable attack = null;

    public Alien() {
        setAnimation(new Animation("sprites/alien.png", 32, 32, 0.1f, Animation.PlayMode.LOOP_PINGPONG));
        health = new Health(100, 100);
        health.onFatigued(this::onExhaustion);
    }

    public Alien(int healthValue, Behaviour<? super Alien> behaviour) {
        this();
        health.setHp(healthValue);
        this.behaviour = behaviour;
        health.onFatigued(this::onExhaustion);
    }

    private void onExhaustion() {
        Scene scene = getScene();
        if (scene != null) {
            scene.removeActor(this);
        }
    }

    @Override
    public int getSpeed() {
        return 2;
    }

    @Override
    public Health getHealth() {
        return health;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        if (behaviour != null) {
            behaviour.setUp(this);
        }
        scheduleAttack();
    }

    private void scheduleAttack() {
        attack = new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::performAttack),
                new Wait<>(0.3f)
            )
        ).scheduleFor(this);
    }

    private void performAttack() {
        Scene scene = getScene();
        if (scene == null) {
            return;
        }
        List<Actor> actors = scene.getActors();

        for (Actor actor : actors) {
            if (actor instanceof Alive && !(actor instanceof Enemy) && this.intersects(actor)) {
                ((Alive) actor).getHealth().drain(3);
                new ActionSequence<>(
                    new Invoke<>(this::stopAttack),
                    new Wait<>(1),
                    new Invoke<>(this::performAttack)
                ).scheduleFor(this);
            }
        }
    }

    private void stopAttack() {
        if (attack != null) {
            attack.dispose();
            attack = null;
        }
    }
}
