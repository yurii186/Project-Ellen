package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Usable;

public class ButtonGreen extends InventoryCommand implements Usable<Ripley> {

    private boolean use;
    public ButtonGreen(){
        setAnimation(new Animation("sprites/button_green.png",16,16));
        use = false;
    }

    @Override
    public void useWith(Ripley actor) {
        if (!use) {
            long appleCount = actor.getBackpack().getContent().stream().filter(item -> item instanceof Apple).count();
            if (appleCount == 1) {
                Apple apple = new Apple();
                actor.getBackpack().add(apple);
                checkInventory(actor);
            } else {
                Heart heart = new Heart();
                actor.getBackpack().add(heart);
                // activateDamageLoop(actor);
            }
        }
    }
//    private void activateDamageLoop(Ripley actor) {
//        Heart heart = (Heart) actor.getBackpack().peek();
//        if (heart != null) {
//            heart.addedToScene(actor.getScene());
//        }
//    }
private void damage() {
    Scene scene = getScene();
    if (scene == null) return;

    Ripley ripley = scene.getFirstActorByType(Ripley.class);
    if (ripley != null && ripley.getBackpack().getContent().stream().anyMatch(item -> item instanceof Heart)) {
        ripley.getHealth().drain(1);
    }
}
    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }

    @Override
    public void addedToScene(Scene scene) {
        super.addedToScene(scene);
        new Loop<>(new ActionSequence<>(new Invoke<>(this::damage), new Wait<>(1))).scheduleOn(scene);
        // new Loop<>(new Invoke<>(this::damage)).scheduleOn(scene);
    }
}
