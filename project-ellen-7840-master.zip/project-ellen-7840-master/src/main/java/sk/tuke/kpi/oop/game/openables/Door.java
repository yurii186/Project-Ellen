package sk.tuke.kpi.oop.game.openables;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.map.MapTile;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.items.Usable;

public class Door extends AbstractActor implements Openable, Usable<Actor> {
    private boolean opened;
    public static final Topic<Door> DOOR_OPENED = Topic.create("door opened", Door.class);
    public static final Topic<Door> DOOR_CLOSED = Topic.create("door closed", Door.class);

    private Animation openedDoorAnimation;
    private Animation closedDoorAnimation;

    private enum Orientation { VERTICAL, HORIZONTAL }

    public Door() {
        this("door", Orientation.VERTICAL);
    }

    public Door(String name, Orientation orientation) {
        super(name);

        String sourceOfAnimation = orientation == Orientation.HORIZONTAL ? "sprites/hdoor.png" : "sprites/vdoor.png";

        closedDoorAnimation = new Animation(sourceOfAnimation, 16, 32, 0.1f, Animation.PlayMode.ONCE);
        openedDoorAnimation = new Animation(sourceOfAnimation, 16, 32, 0.1f, Animation.PlayMode.ONCE_REVERSED);

        setAnimation(new Animation(sourceOfAnimation, 16, 32));
        getAnimation().stop();
        opened = false;
    }


    @Override
    public void useWith(Actor actor) {
        if (isOpen()) {
            close();
        } else {
            open();
        }
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }

    @Override
    public void open() {
        opened = true;
        Scene scene = getScene();
        if (scene != null) {
            scene.getMap().getTile(getPosX() / 16, getPosY() / 16).setType(MapTile.Type.CLEAR);
            scene.getMap().getTile(getPosX() / 16, getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
            getAnimation().play();
            setAnimation(openedDoorAnimation);
            getAnimation().stop();
            scene.getMessageBus().publish(DOOR_OPENED, this);
        }
    }

    @Override
    public void close() {
        opened = false;
        Scene scene = getScene();
        if (scene != null) {
            scene.getMap().getTile(getPosX() / 16, getPosY() / 16).setType(MapTile.Type.WALL);
            scene.getMap().getTile(getPosX() / 16, getPosY() / 16 + 1).setType(MapTile.Type.WALL);
            getAnimation().play();
            setAnimation(closedDoorAnimation);
            getAnimation().stop();
            scene.getMessageBus().publish(DOOR_CLOSED, this);
        }
    }

    @Override
    public boolean isOpen() {
        return opened;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        scene.getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.WALL);
        scene.getMap().getTile(this.getPosX() / 16, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
    }
}

