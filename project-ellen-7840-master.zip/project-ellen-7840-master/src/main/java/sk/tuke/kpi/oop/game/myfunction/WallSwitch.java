package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.oop.game.items.Usable;
import sk.tuke.kpi.oop.game.openables.LockedDoor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class WallSwitch extends AbstractActor implements Usable<Actor> {

    public WallSwitch() {
        setAnimation(new Animation("sprites/wall_switch.png", 16, 16));
    }

//    @Override
//    public void useWith(Actor actor) {
//        Scene scene = getScene();
//        LockedDoor lockedDoor = scene.getFirstActorByType(LockedDoor.class);
//        if(lockedDoor.isOpen()) {
//            lockedDoor.lock();
//        }
//        else {
//            lockedDoor.unlock();
//        }
//    }
@Override
public void useWith(Actor actor) {
    Scene scene = getScene();
    if (scene == null) return;

    double closestDistance = Double.MAX_VALUE;
    LockedDoor closestDoor = null;

    int actorX = actor.getPosX();
    int actorY = actor.getPosY();

    for (Actor sceneActor : scene.getActors()) {
        if (sceneActor instanceof LockedDoor) {
            int doorX = sceneActor.getPosX();
            int doorY = sceneActor.getPosY();

            double distance = Math.sqrt(Math.pow(actorX - doorX, 2) + Math.pow(actorY - doorY, 2));

            if (distance < closestDistance) {
                closestDistance = distance;
                closestDoor = (LockedDoor) sceneActor;
            }
        }
    }

    if (closestDoor != null) {
        if (closestDoor.isOpen()) {
            closestDoor.lock();
        } else {
            closestDoor.unlock();
        }
    }
}



    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }
}
