package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.*;
import sk.tuke.kpi.gamelib.backends.lwjgl.LwjglBackend;
import sk.tuke.kpi.oop.game.scenarios.Game;

public class Main {
    public static void main(String[] args) {

        WindowSetup windowSetup = new WindowSetup("Project Ellen", 800, 600);

        sk.tuke.kpi.gamelib.Game game = new GameApplication(windowSetup, new LwjglBackend());

        Scene scene = new World("world", "maps/Game.tmx", new Game.Factory());
       // Scene scene = new World("world","maps/mission-impossible.tmx");

        Game missionImpossible = new Game();

        game.addScene(scene);

        scene.addListener(missionImpossible);

        game.getInput().onKeyPressed(Input.Key.ESCAPE, () -> game.stop());

        game.start();
    }
}
