package sk.tuke.kpi.oop.game.myfunction;


public interface Command {
    void execute();
}
