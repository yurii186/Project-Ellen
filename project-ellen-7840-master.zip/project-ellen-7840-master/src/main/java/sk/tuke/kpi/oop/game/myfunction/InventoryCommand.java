package sk.tuke.kpi.oop.game.myfunction;


import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Backpack;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;


public abstract class InventoryCommand extends AbstractActor implements Usable<Ripley> {

    public void checkInventory(Ripley actor) {
        Backpack backpack = actor.getBackpack();
        long appleCount = backpack.getContent().stream().filter(item -> item instanceof Apple).count();

        if (appleCount == 2) {
            GoldApple goldApple = new GoldApple();
            backpack.add(goldApple);
            int removedCount = 0;

            for (Collectible item : backpack.getContent()) {
                if (item instanceof Apple && removedCount < 2) {
                    backpack.remove(item);
                    removedCount++;
                }
            }
        }
    }
}
