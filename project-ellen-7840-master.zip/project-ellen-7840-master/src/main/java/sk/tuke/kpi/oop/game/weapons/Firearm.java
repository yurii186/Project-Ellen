package sk.tuke.kpi.oop.game.weapons;

public abstract class Firearm {
    private int ammoNow;
    private int ammoMax;

    public Firearm(int initialAmmo, int maxAmmo) {
        this.ammoNow = initialAmmo;
        this.ammoMax = maxAmmo;
    }

    public Firearm(int initialAmmo) {
        this.ammoNow = initialAmmo;
        this.ammoMax = initialAmmo;
    }

    public int getAmmo() {
        return ammoNow;
    }

    public int getMaxAmmo() {
        return ammoMax;
    }

    public void decreaseAmmo(int amount) {
        if (ammoNow != 0) {
            ammoNow -= amount;
        }
        if (ammoNow < 0) {
            ammoNow = 0;
        }
    }

    public void reload(int newAmmo) {
        if (getAmmo() + newAmmo < ammoMax) {
            ammoNow += newAmmo;
        } else {
            ammoNow = ammoMax;
        }
    }

    protected abstract Fireable createBullet();

    public Fireable fire() {
        if (ammoNow != 0) {
            ammoNow--;
            return createBullet();
        } else {
            return null;
        }
    }
}
