package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.oop.game.characters.Ripley;

public class AppleInteraction implements InteractionStrategy {
    @Override
    public void interact(Ripley ripley) {
        if (!ripley.isInvincible()) {
            ripley.setInvincible(true);
        }
    }
}
