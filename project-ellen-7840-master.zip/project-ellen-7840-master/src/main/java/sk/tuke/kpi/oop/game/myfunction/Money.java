package sk.tuke.kpi.oop.game.myfunction;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.items.Collectible;

public class Money extends AbstractActor implements Collectible {
    public Money(){
        setAnimation(new Animation("sprites/money.png"));
    }
}
